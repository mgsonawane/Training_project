import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {
  edit:boolean=false;
  view:boolean=false;
  
  constructor() { }
  
  ngOnInit() {
  }
public editprofile(){
this.view=false;
this.edit=true;
}
public viewprofile(){
  this.edit=false;
  this.view=true;
}
}