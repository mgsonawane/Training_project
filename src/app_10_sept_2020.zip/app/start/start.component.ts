// Default Starting page. 
import { Component, OnInit } from '@angular/core';
import { Router  } from '@angular/router';
@Component({
  selector: 'app-start',
  templateUrl: './start.component.html',
  styleUrls: ['./start.component.css']
})
export class StartComponent implements OnInit {
  wrongpass=false;
  model: any={}
  submitted = false;
  err:boolean = false ;
  temp:any=[];
  constructor( private router :Router) { }
  ngOnInit() {
  this.temp=JSON.parse(localStorage.getItem("users"));
  console.log(this.temp);
    sessionStorage.clear();
  }
  public changecolor(){
    this.wrongpass=false;
    this.submitted=false;
    this.err=false;
  }
  // Sumbit function
  public onSubmit() {
      this.submitted = true;
      //console.log(this.model);
      // stop here if form is invalid
      for(var i=0;i<localStorage.length;i++)
            {
              if ( (this.model.user_email === this.temp[i]["email"]
                || this.model.userpassword === this.temp[i]["password"] ) ) {
                this.router.navigate(["/"]);
                  this.wrongpass = false;
                  sessionStorage.setItem("logged","true");
                  sessionStorage.setItem("first_name",this.temp[i]["first_name"]);
                  sessionStorage.setItem("last_name",this.temp[i]["last_name"]);
                  sessionStorage.setItem("email",this.temp[i]["email"]);
                  sessionStorage.setItem("address",this.temp[i]["address"]);
                  sessionStorage.setItem("mobile",this.temp[i]["mobile_no"]);
                  sessionStorage.setItem("gender",this.temp[i]["gender"]);

                  this.router.navigate(['/home']);
                }
            }
      if  ( !this.model.userpassword && !this.model.user_email ) 
        {
          this.wrongpass = false;
          this.err = false;
        }
      else{
          this.wrongpass=true;
          this.err=true;
          
        }
    }
  // Signup component
public signup(){
  this.router.navigate((['\signup']));
  }
  // Forget-password component
public forget(){
  //console.log("hello");
  this.router.navigate((['forgetpassword']));
}
}
